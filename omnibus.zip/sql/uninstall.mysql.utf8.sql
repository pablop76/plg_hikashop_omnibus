DROP TABLE IF EXISTS `#__hikashop_price_history`;
